var i = 0;

function button_click() {
    i = i + 1;
    document.getElementById("replace_p").innerHTML= i + "";
}